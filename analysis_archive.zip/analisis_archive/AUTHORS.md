# Initial authors of this library

- Reynald Affeldt, AIST (National Institute of Advanced Industrial Science and Technology, Japan)
- Cyril Cohen, Inria
- Assia Mahboubi, Inria
- Damien Rouhling, Inria
- Pierre-Yves Strub, École polytechnique
